package kuis2praktikumASD;

public class Node_21 {
        Pesanan data;
        Node_21 prev;
        Node_21 next;
    
        public Node_21(Pesanan data) {
            this.data = data;
            this.prev = null;
            this.next = null;
        }
    }
    

