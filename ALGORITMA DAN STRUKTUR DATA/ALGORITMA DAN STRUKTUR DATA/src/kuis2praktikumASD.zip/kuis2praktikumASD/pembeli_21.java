package kuis2praktikumASD;

public class pembeli_21 { 
    String namaPembeli;
    String NoHp;

    public pembeli_21(String namaPembeli, String NoHp) {
        this.namaPembeli = namaPembeli;
        this.NoHp = NoHp;
    }
}

