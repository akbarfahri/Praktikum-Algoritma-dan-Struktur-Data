package P7;
import java.util.Scanner;

public class BukuMain21 {
public static void main(String[] args) {
    Scanner s = new Scanner(System.in);
    Scanner s1 = new Scanner(System.in);

    pencarianBuku data = new pencarianBuku();
    int jumBuku = 5;

    System.out.println("=======================================");
    System.out.println("Masukan data buku secara urut dari kodeBuku terkecil : ");
    for (int i = 0; i < jumBuku; i++) {
        System.out.println("===================================");
        System.out.print("Kode Buku \t: ");
        int kodeBuku = s.nextInt();
        System.out.print("Judul Buku \t: ");
        String judulBuku = s1.nextLine();
        System.out.print("Tahun Terbit \t: ");
        int tahunTerbit = s.nextInt();
        System.out.print("Pengarang \t: ");
        String pengarang = s1.nextLine();
        System.out.print("Stock \t: ");
        int stock = s.nextInt();

        Buku21 m = new Buku21(kodeBuku, judulBuku, tahunTerbit, pengarang, stock);
        data.tambah(m);
    }
    System.out.println("====================================");
    System.out.println("Data Keseluruhan Buku : ");
    data.tampil();

    System.out.println("_________________________________________");
    System.out.println("_________________________________________");
    System.out.println("Pencarian Data : ");
    System.out.println("Masukan kode buku yang ingin dicari : ");
    System.out.print("Kode buku : ");
    int cari = s.nextInt();
    System.out.println("Menggunakan sequential Search");
    int posisi = data.FindSeqSearch(cari);
    data.TampulPosisi(cari, posisi);

  
    s.close();
    s1.close();
}
}

