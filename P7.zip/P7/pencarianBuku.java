package P7;

public class pencarianBuku {
    Buku21 listBK[] = new Buku21[5];
    int idx;

    void tambah(Buku21 m) {
        if (idx < listBK.length) {
            listBK[idx] = m;
            idx++;
        } else {
            System.out.println("Data Sudah Penuh!");
        }
    }

    void tampil() {
        if (idx == 0) {
            System.out.println("Tidak ada data buku.");
            return;
        }

        for (Buku21 buku : listBK) {
            if (buku != null) {
                buku.tampilkanDataBuku();
            }
        }
    }

    public int FindSeqSearch(int cari) {
        int posisi = -1; 
        for (int j = 0; j < listBK.length; j++) {
            if (listBK[j] != null && listBK[j].kodeBuku == cari) {
                posisi = j;
                break; 
            }
        }
        return posisi;
    }

    public void TampulPosisi(int x, int pos){
        if (pos != -1) {
            System.out.println("Data : " + x + " ditemukan pada index " + pos);
        } else {
            System.out.println("Data : " + x + " Tidak ditemukan");
        }
    }
}
